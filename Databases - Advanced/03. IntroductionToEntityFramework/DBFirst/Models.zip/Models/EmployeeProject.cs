﻿namespace SoftUni.Models
{
    using System;
    using System.Collections.Generic;

    public class EmployeeProject
    {
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }

        public int ProjectId { get; set; }
        public Project Project { get; set; }
    }
}
